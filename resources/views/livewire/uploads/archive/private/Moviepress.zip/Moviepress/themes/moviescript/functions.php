<?php
add_filter('show_admin_bar', '__return_false');
remove_action('personal_options', '_admin_bar_preferences');
add_theme_support( 'post-thumbnails' );
?>
<?php
function wp_limit_post($max_char, $more_link_text = '[...]',$notagp = false, $stripteaser = 0, $more_file = '') {
    $content = get_the_content($more_link_text, $stripteaser, $more_file);
    $content = apply_filters('the_content', $content);
    $content = str_replace(']]>', ']]&gt;', $content);
    $content = strip_tags($content);

   if (strlen($_GET['p']) > 0) {
      if($notagp) {
      echo substr($content,0,$max_char);
      }
      else {
      echo '<p>';
      echo substr($content,0,$max_char);
      echo "</p>";
      }
   }
   else if ((strlen($content)>$max_char) && ($espacio = strpos($content, " ", $max_char ))) {
        $content = substr($content, 0, $espacio);
        $content = $content;
        if($notagp) {
        echo substr($content,0,$max_char);
        echo $more_link_text;
        }
        else {
        echo '<p>';
        echo substr($content,0,$max_char);
        echo $more_link_text;
        echo "</p>";
        }
   }
   else {
      if($notagp) {
      echo substr($content,0,$max_char);
      }
      else {
      echo '<p>';
      echo substr($content,0,$max_char);
      echo "</p>";
      }
   }
}
?>
<?php
// Directores
	register_taxonomy('director', 'post', array(
	'hierarchical' => false,  'label' => 'Director',
	'query_var' => true, 'rewrite' => true));
// Escritores
	register_taxonomy('escritor', 'post', array(
	'hierarchical' => false,  'label' => 'Escritores',
	'query_var' => true, 'rewrite' => true));
// Actores
	register_taxonomy('actor', 'post', array(
	'hierarchical' => false,  'label' => 'Actores',
	'query_var' => true, 'rewrite' => true));
// Año de estreno
	register_taxonomy('fecha-estreno', 'post', array(
	'hierarchical' => false,  'label' => 'Año',
	'query_var' => true, 'rewrite' => true));
// Lenguaje
	register_taxonomy('lenguaje', 'post', array(
	'hierarchical' => false,  'label' => 'Lenguaje',
	'query_var' => true, 'rewrite' => true));
// Si es pelicula, Serie, Estreno
	register_taxonomy('archivos', 'post', array(
	'hierarchical' => false,  'label' => 'Poner los tags que correspondan: estrenos, peliculas, series',
	'query_var' => true, 'rewrite' => true));
// Si es series: elejir nombre del capitulo
	register_taxonomy('serie', 'post', array(
	'hierarchical' => false,  'label' => 'Nombre de la serie, para todos los capitulos siempre va a ir el mismo nombre',
	'query_var' => true, 'rewrite' => true));
// Si es series: Temporada
	register_taxonomy('temporada', 'post', array(
	'hierarchical' => false,  'label' => 'Temporada del capitulo, Ej: 1, 2',
	'query_var' => true, 'rewrite' => true));
// Si es series: Capitulo
	register_taxonomy('capitulo', 'post', array(
	'hierarchical' => false,  'label' => 'Capitulo, Ej: 1, 2',
	'query_var' => true, 'rewrite' => true));
?>
<?php
if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
	    'name' => 'Sidebar',
		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
}
?>
<?php
$sp_boxes = array (
	'Auto-Completar con IMDB (Utiliza el titulo), Solo tienen que escribir un caracter' => array (
		array( 'Checkbx', 'Dar clik', 'checkbox' ),
		array( 'Checkbx2', 'ID de IMDB (Ejemplo: http://www.imdb.com/title/tt0232500/ el ID es "tt0232500")' ),
	),
    'Informacion de la Pelicula (IMBD)' => array (
        array( 'Poster', 'Caratual (120px*176px) - usar http://:' ),
		array( 'Title', 'Nombre original:' ),
		array( 'Year', 'Año de Lanzamiento:' ),
		array( 'Rated', 'Audencia:' ),
		array( 'Released', 'Lanzamiento:' ),
		array( 'Runtime', 'Duracion:' ),
        array( 'Genre', 'Genero:' ),
		array( 'Director', 'Director:' ),
		array( 'Writer', 'Escritores:' ),
		array( 'Actors', 'Actores:' ),
        array( 'Lang', 'Lenguaje:' ),
        array( 'imdbRating', 'IMDB Rating:' ),
        array( 'Trailer', 'Trailer:', 'textarea' ),
		array( 'Descargas', 'Descargas:', 'textarea' ),
    ),
    'Reproductores' => array (
        array( 'reproductor', 'Codigo HTML o Iframe del Reproductor:', 'textarea' ),
    ),
);

// Use the admin_menu action to define the custom boxes
add_action( 'admin_menu', 'sp_add_custom_box' );

// Use the save_post action to do something with the data entered
// Save the custom fields
add_action( 'save_post', 'sp_save_postdata', 1, 2 );

// Adds a custom section to the "advanced" Post and Page edit screens
function sp_add_custom_box() {
    global $sp_boxes;

    if ( function_exists( 'add_meta_box' ) ) {

        foreach ( array_keys( $sp_boxes ) as $box_name ) {
            add_meta_box( $box_name, __( $box_name, 'sp' ), 'sp_post_custom_box', 'post', 'normal', 'high' );
        }
    }
}

function sp_post_custom_box ( $obj, $box ) {
    global $sp_boxes;
    static $sp_nonce_flag = false;

    // Run once
    if ( ! $sp_nonce_flag ) {
        echo_sp_nonce();
        $sp_nonce_flag = true;
    }

    // Genrate box contents
    foreach ( $sp_boxes[$box['id']] as $sp_box ) {
        echo field_html( $sp_box );
    }
}

function field_html ( $args ) {

    switch ( $args[2] ) {

        case 'textarea':
            return text_area( $args );

        case 'checkbox':
            // To Do

        case 'radio':
            // To Do

        case 'text':
        default:
            return text_field( $args );
    }
}

function text_field ( $args ) {
    global $post;

    // adjust data
    $args[2] = get_post_meta($post->ID, $args[0], true);
    $args[1] = __($args[1], 'sp' );

    $label_format =
          '<label for="%1$s">%2$s</label><br />'
        . '<input style="width: 95%%;" type="text" name="%1$s" value="%3$s" /><br /><br />';

    return vsprintf( $label_format, $args );
}

function text_area ( $args ) {
    global $post;

    // adjust data
    $args[2] = get_post_meta($post->ID, $args[0], true);
    $args[1] = __($args[1], 'sp' );

    $label_format =
          '<label for="%1$s">%2$s</label><br />'
        . '<textarea style="width: 95%%;" name="%1$s">%3$s</textarea><br /><br />';

    return vsprintf( $label_format, $args );
}

/* When the post is saved, saves our custom data */
function sp_save_postdata($post_id, $post) {
    global $sp_boxes;

    // verify this came from the our screen and with proper authorization,
    // because save_post can be triggered at other times
    if ( ! wp_verify_nonce( $_POST['sp_nonce_name'], plugin_basename(__FILE__) ) ) {
        return $post->ID;
    }

    // Is the user allowed to edit the post or page?
    if ( 'page' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_page', $post->ID ))
            return $post->ID;

    } else {
        if ( ! current_user_can( 'edit_post', $post->ID ))
            return $post->ID;
    }

    // OK, we're authenticated: we need to find and save the data
    // We'll put it into an array to make it easier to loop though.

    // The data is already in $sp_boxes, but we need to flatten it out.
    foreach ( $sp_boxes as $sp_box ) {
        foreach ( $sp_box as $sp_fields ) {
            $my_data[$sp_fields[0]] =  $_POST[$sp_fields[0]];
        }
    }

    // Add values of $my_data as custom fields
    // Let's cycle through the $my_data array!
    foreach ($my_data as $key => $value) {
        if ( 'revision' == $post->post_type  ) {
            // don't store custom data twice
            return;
        }

        // if $value is an array, make it a CSV (unlikely)
        $value = implode(',', (array)$value);

        if ( get_post_meta($post->ID, $key, FALSE) ) {

            // Custom field has a value.
            update_post_meta($post->ID, $key, $value);


        } else {

            // Custom field does not have a value.
            add_post_meta($post->ID, $key, $value);
        }

        if (!$value) {

            // delete blanks
            delete_post_meta($post->ID, $key);
        }
    }
}

function echo_sp_nonce () {

    // Use nonce for verification ... ONLY USE ONCE!
    echo sprintf(
        '<input type="hidden" name="%1$s" id="%1$s" value="%2$s" />',
        'sp_nonce_name',
        wp_create_nonce( plugin_basename(__FILE__) )
    );
}

// A simple function to get data stored in a custom field
if ( !function_exists('get_custom_field') ) {
    function get_custom_field($field) {
       global $post;
       $custom_field = get_post_meta($post->ID, $field, true);
       echo $custom_field;
    }
}

?>
<?php
// IMDB autocompletar datos
function custom_admin_js() {
	/*echo '$(\'input[name=Lang]\').keypress(function() {
		var valor = $(\'input[name=Lang]\').get(0).value;
		$(\'#new-tag-lenguaje\').val(valor);
	});';*/
    echo '<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js "></script>
	<script>
	$(\'input[name=Checkbx]\').click(function() {
	var imdbLink = $(\'input[name=Checkbx2]\').get(0).value;
	// Send Request
	$.getJSON("http://www.omdbapi.com/?i=" + imdbLink, function(data) {
		var valDir = "";
		var valWri = "";
		var valAct = "";
		$.each(data, function(key, val) {
			  $(\'input[name=\' +key+ \']\').val(val); 
			  if(key == "Director"){
				valDir+= " "+val+",";
			  }
			  if(key == "Writer"){
				valWri+= " "+val+",";
			  }
			  if(key == "Actors"){
				valAct+= " "+val+",";
			  }
			  if(key == "Year"){
				$(\'#new-tag-fecha-estreno\').val(val);
			  }
		});
		$(\'#new-tag-director\').val(valDir);
		$(\'#new-tag-escritor\').val(valWri);
		$(\'#new-tag-actor\').val(valAct);
		alert(\'Se te genero todo automaticamente, pero en el slider tenes que apretar "Agregar" en cada box.\');
	}); 
});
</script>';
}
add_action('admin_footer', 'custom_admin_js');
?>
<?php
// No borrar, respeta los creditos, es un script gratuito
function copyright(){ echo "<br /><br />Powered by <a href='http://www.marcofbb.com.ar/moviescript-para-wordpress-crea-tu-web-de-peliculas/' class='copyright' title='MovieScript para Wordpress'>MoviePress</a> & <a href='http://es.wordpress.org/' class='CopyrightWP'>Wordpress</a><!-- http://www.marcofbb.com.ar/ --><!-- Powered by MoviePress Script For Wordpress -->"; }
?>
<?php add_action('wp_footer', 'copyright'); ?>
<?php
// Buscador de primera letra
add_filter('posts_search', 'mi_search_title');
function mi_search_title($search) {
  preg_match('/letra-([^%]+)/', $search, $m);
  if (isset($m[1])) {
    // Original
    // " AND (((wp_posts.post_title LIKE '%termino%') OR (wp_posts.post_content LIKE '%termino%')))  AND (wp_posts.post_password = '') "
    return " AND wp_posts.post_title LIKE '$m[1]%' AND (wp_posts.post_password = '') ";
  } else {
    return $search;
  }
}
?>