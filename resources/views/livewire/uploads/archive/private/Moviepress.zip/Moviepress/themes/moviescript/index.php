<?php get_header(); ?>
<script type="text/javascript">
  $(function () {

    var pane = $('#scrollpane1');

    pane.jScrollPane({
     animateScroll: true,
     animateDuration: 50
   });

    var api = pane.data('jsp');

    $('#scrollpane1-container .leftScroll').bind('mouseover', function () {
      $('#scrollpane1-container .rightScroll').css('display', 'block');
      var leftScrollInterval = setInterval(function () {
        if (api.getPercentScrolledX() != 0)

       api.scrollByX(-10);
        else $('#scrollpane1-container .leftScroll').css('display', 'none');
      }, 50);
      $('#scrollpane1-container .leftScroll').bind('mouseout', function () {
        clearInterval(leftScrollInterval);
      });
    });


   $('#scrollpane1-container .rightScroll').bind('mouseover', function () {
      $('#scrollpane1-container .leftScroll').css('display', 'block');
      var rightScrollInterval = setInterval(function () {
        if (api.getPercentScrolledX() != 1)
        api.scrollByX(10);
        else $('#scrollpane1-container .rightScroll').css('display', 'none');
      }, 50);
      $('#scrollpane1-container .rightScroll').bind('mouseout', function () {
        clearInterval(rightScrollInterval);
      });
    });
  });
</script>
<div id="wrapper" class="hfeed">
	<div id="main">
    	<div id="container">
			<div id="content" role="main">
				<h1>&Uacute;ltimos Estrenos &raquo;</h1>
				<strong><a class="ver-todos" href="<?php bloginfo('url'); ?>/archivos/estrenos/" title="Ver todas las películas de Estreno"><span style="color: #ca0000;font-weight: bold;text-shadow: 0 1px 0 #f9fdff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ver todas las películas de Estreno &raquo;</span></a></strong>
				<div class="cuevana-scrollpane-container" id="scrollpane1-container">
                   	<div class="leftScroll"></div>
					<div class="rightScroll"></div>
					<div class="cuevana-scrollpane" id="scrollpane1">
						<div style="margin-right:-1580px";>
                        <?php
							$args = array(
								'archivos'=> 'estrenos',
								'posts_per_page' => 13,
							);
						?>
                        <?php query_posts( $args ); ?>
                       	<!-- WHILE -->
                        <?php while ( have_posts() ) : the_post(); ?>
                       		<div class="poster post-<?php the_ID(); ?>">
                                <a class="aimg" href="<?php the_permalink() ?>" rel="tooltip" title='<h2><?php the_title(); ?></h2><p><?php wp_limit_post(170,'[...]',true); ?></p><h2></h2><p></p><p><strong>Reparto: </strong><?php echo get_the_term_list($post->ID, 'actor', '', ', ', ''); ?></p><p><strong>Género: </strong><?php the_category(', '); ?></p><p><strong>Duración: </strong><?php $values = get_post_custom_values("Runtime"); echo $values[0]; ?></p>'>
                                <?php the_post_thumbnail(array(128,171)); ?></a>
                                <div class="mdata">
                                    <a href="<?php the_permalink() ?>"><strong><?php the_title(); ?></strong></a><br />
                                    <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
                                </div>
                            </div>
                      		<!-- FIN WHILE -->
                      <?php endwhile; ?>
                      <?php wp_reset_query(); ?>
						</div>
                   	</div>
                </div>
                <h1>&Uacute;ltimas Pel&iacute;culas Agregadas &raquo;</h1>
				<strong><a class="ver-todos" style="margin-left:240px;" href="<?php bloginfo('url'); ?>/archivos/peliculas" title="Ver todas las peliculas"><span style="color: #ca0000;font-weight: bold;text-shadow: 0 1px 0 #f9fdff;">Ver Listado de Peliculas »</span></a></strong>
				<div class="cuevana-scrollpane-container" id="scrollpane1-container">
                   	<div class="leftScroll"></div>
					<div class="rightScroll"></div>
					<div class="cuevana-scrollpane" id="scrollpane1">
						<div style="margin-right:-1580px";>
                        <?php
							$args = array(
								'archivos'=> 'peliculas',
								'posts_per_page' => 13,
							);
						?>
                        <?php query_posts( $args ); ?>
                       	<!-- WHILE -->
                        <?php while ( have_posts() ) : the_post(); ?>
                       		<div class="poster post-<?php the_ID(); ?>">
                                <a class="aimg" href="<?php the_permalink() ?>" rel="tooltip" title='<h2><?php the_title(); ?></h2><p><?php wp_limit_post(170,'[...]',true); ?></p><h2></h2><p></p><p><strong>Reparto: </strong><?php echo get_the_term_list($post->ID, 'actor', '', ', ', ''); ?></p><p><strong>Género: </strong><?php the_category(', '); ?></p><p><strong>Duración: </strong><?php $values = get_post_custom_values("Runtime"); echo $values[0]; ?></p>'>
                                <?php the_post_thumbnail(array(128,171)); ?></a>
                                <div class="mdata">
                                    <a href="<?php the_permalink() ?>"><strong><?php the_title(); ?></strong></a><br />
                                    <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
                                </div>
                            </div>
                      		<!-- FIN WHILE -->
                      <?php endwhile; ?>
                      <?php wp_reset_query(); ?>
						</div>
                   	</div>
                </div>
                <h1 style="margin-top:15px;">Series | &Uacute;ltimos Espisodios &raquo;</h1>
				<strong><a class="ver-todos" style="margin-left:240px;" href="<?php bloginfo('url'); ?>/series" title="Ver todas las series"><span style="color: #ca0000;font-weight: bold;text-shadow: 0 1px 0 #f9fdff;">Ver Listado de Series »</span></a></strong>
				<div class="cuevana-scrollpane-container" id="scrollpane1-container">
                   	<div class="leftScroll"></div>
					<div class="rightScroll"></div>
					<div class="cuevana-scrollpane" id="scrollpane1">
						<div style="margin-right:-1580px";>
                        <?php
							$args = array(
								'archivos'=> 'series',
								'posts_per_page' => 13,
							);
						?>
                        <?php query_posts( $args ); ?>
                       	<!-- WHILE -->
                        <?php while ( have_posts() ) : the_post(); ?>
                       		<div class="poster post-<?php the_ID(); ?>">
                                <a class="aimg" href="<?php the_permalink() ?>" rel="tooltip" title='<h2><?php the_title(); ?></h2><p><?php wp_limit_post(170,'[...]',true); ?></p><h2></h2><p></p><p><strong>Reparto: </strong><?php echo get_the_term_list($post->ID, 'actor', '', ', ', ''); ?></p><p><strong>Género: </strong><?php the_category(', '); ?></p><p><strong>Duración: </strong><?php $values = get_post_custom_values("Runtime"); echo $values[0]; ?></p>'>
                                <?php the_post_thumbnail(array(128,171)); ?></a>
                                <div class="mdata">
                                    <a href="<?php the_permalink() ?>"><strong><?php the_title(); ?></strong></a><br />
                                    <?php if(function_exists('the_ratings')) { the_ratings(); } ?>
                                </div>
                            </div>
                      		<!-- FIN WHILE -->
                      <?php endwhile; ?>
                      <?php wp_reset_query(); ?>
						</div>
                   	</div>
                </div>
			</div>
		</div>  
        <?php get_sidebar(); ?>     
	</div>
</div>
                  	

<?php get_footer(); ?>