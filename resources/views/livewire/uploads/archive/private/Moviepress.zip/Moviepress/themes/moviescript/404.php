<?php get_header(); ?>
<div id="wrapper" class="hfeed">
	<div id="main">
		<div id="container">
        	<div id="content" role="main">
				<h1> <strong>Error 404</strong></h1>
                <p>Lo sentimos, pero que esta buscando algo que no esta aqui. </p>
			</div>
		</div>
        <?php get_sidebar(); ?> 
	</div>
</div>
<?php get_footer(); ?>