<?php get_header(); ?>
<script type="text/javascript">
  $(document).ready(function ()
  {
    $(".tab_content").hide();
    $("ul.tabs li:first").addClass("active").show();
    $(".tab_content:first").show();
    $("ul.tabs li").click(function ()
    {
      $("ul.tabs li").removeClass("active");
      $(this).addClass("active");
      $(".tab_content").hide();
      var activeTab = $(this).find("a").attr("href");
      $(activeTab).fadeIn();
      return false;
    });
    $("#reproducir").click(function ()
    {
      $("#reproducir").hide();
      $("#reproductor").show();
    });
  });
</script>
<style type="text/css">
<!--
	.Estilo2 {font-size: 14px}
-->
</style>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div style="background-image:url(<?php bloginfo( 'template_url' ); ?>/css/images/fondo-video.png);background-repeat:repeat; margin-top:-20px; width:100%; height:50px;">
   	<div class="container1">
		<div style="margin: 20px 20px 20px 25px;">
			<hr width="0%">
			<h1 class="entry-title" style="margin-top: -25px;"><strong><span style="text-decoration: underline;"><?php the_title(); ?></span> <span>(<?php 
																			$values = get_post_custom_values("Year"); 
																			echo '<a href="./?fecha-estreno='.$values[0].'">'.$values[0].'</a>'; 
																		?>)</span></strong></h1>
		</div>
    </div>
</div>
<div class="mdata">
	<div class="clear:both;"></div>
    <div class="mr"><!-- <span  class='st_twitter_hcount' displayText='Tweet'></span><span  class='st_facebook_hcount' displayText='Facebook'></span><span  class='st_fblike_hcount' ></span><span  class='st_plusone_hcount' ></span> -->
	</div>
</div>
<div class="playercont">
	<p>&nbsp;</p>
	<div class="playerin" style="margin-top:21px";>
    	<?php $values = get_post_custom_values("reproductor"); echo $values[0]; ?>
		<?php //<iframe width="650" height="360" scrolling="no" src="http://tekilaz.com/java/play.php?ra=AAAAaB8B&bs=eukqf1iu&bf=iecg/B0fzCl/Aba8a.psC&fb=b3jgd1iCgz1m&id=28757&sub=,ES&sub_pre=ES" frameborder="0" allowfullscreen></iframe> ?>
		<div style="margin-top:15px";>
			<div class="gdbr-report broken" style="margin-top:1.5%;margin-right:0.7%";>
				<style type="text/css"> .wprperrorsform {background:none !important; padding:0px 0px 0px 10px;}</style><a class="wprperrorsform" href="#wprperrors"><img src="<?php bloginfo( 'template_url' ); ?>/css/images/reporte.png" title="Reportar error en el video"></a><?php if(function_exists('ReportPageErrors')){ echo ReportPageErrors(); } ?>
          	</div>
		</div>
	</div>
</div>
<div id="wrapper" class="hfeed">
	<div id="main">
		<div style="margin-top:10px";></div>
		<div id="container">
			<div id="content" role="main">
				<div id="post-<?php the_ID(); ?>" class="post-<?php the_ID(); ?> post type-post status-publish format-standard hentry category-estrenos category-peliculas">
				<div class="entry-content"><!-- <h2>Informaci&oacute;n sobre: <strong>MS1: Máxima seguridad</strong> (<strong><a href="<?php bloginfo('url'); ?>/fecha-de-estreno/2012/" rel="tag">2012</a></strong>) </h2> -->
                	<div class="poster">
                    	<a class="aimg" href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
                        <?php the_post_thumbnail(array(128,171)); ?>
                        </a>
                        <div class="mdata"></div>
					</div>
                    <div id="tabber">
                    	<ul class="tabs">
							<li><a href="#tab1">Sinopsis</a></li>
							<li><a href="#tab2">Ficha T&eacute;cnica</a></li>
							<li><a href="#tab3">Trailer</a></li>
                           <?php $values = get_post_custom_values("Descargas"); if($values[0] != NULL){ ?> <li><a href="#tab4">Descargar</a></li><?php } ?>
						</ul>
                        <div class="tab_container">
							<div id="tab1" class="tab_content">
                  				<?php the_content(); ?>
								<hr width=100%>
                                <center><?php if(function_exists('the_ratings')) { the_ratings(); } ?></center>
							</div>            
                            <div id="tab2" class="tab_content">
                  				<div id="ficha-tecnica">
									<ul>
                                    	<?php if(get_the_term_list($post->ID, 'serie', '', ', ', '') != ""){ ?>
                                    	<li><strong>Serie: <?php echo get_the_term_list($post->ID, 'serie', '', ', ', ''); ?></a></strong></li>
                                        <?php } ?>
                                    	<li><strong>T&iacute;tulo Original: <?php $values = get_post_custom_values("Title"); echo '<a href="" title="'.$values[0].'">'.$values[0].'</a>'; ?></a></strong></li>
                                        <li><strong>Lenguaje: <?php echo get_the_term_list($post->ID, 'lenguaje', '', ', ', ''); ?>
</li>
                                        <li><strong>Director: <?php echo get_the_term_list($post->ID, 'director', '', ', ', ''); ?></strong></li>
                                        <li><strong>Escritor(es): <?php echo get_the_term_list($post->ID, 'escritor', '', ', ', ''); ?></strong></li>
                                        <li><strong>Reparto: <?php echo get_the_term_list($post->ID, 'actor', '', ', ', ''); ?></strong></li>
                                        <li><strong>G&eacute;nero: <?php the_category(', '); ?></strong></li>
                                        <li><strong>Fecha de Estreno:	<?php echo get_the_term_list($post->ID, 'fecha-estreno', '', ', ', ''); ?></strong></li>
                                        <li><strong>Duraci&oacute;n: <span style="color: #1A43BE;"><?php $values = get_post_custom_values("Runtime"); echo $values[0]; ?></span></strong></li>
                    				</ul>
								</div>
							</div>
							<div id="tab3" class="tab_content">
								<div style="text-align:center; padding-top:10px;">
									<?php $values = get_post_custom_values("Trailer"); if($values[0] != NULL) echo $values[0]; else echo 'Trailer no disponible'; ?>
								</div>
							</div>
                            <?php $values = get_post_custom_values("Descargas"); if($values[0] != NULL){ ?>
                            <div id="tab4" class="tab_content">
								<div style="text-align:center; padding-top:10px;">
									<?php echo $values[0]; ?>
								</div>
							</div>
                            <?php } ?>
						</div>
					</div>
				</div>
			</div>
			<div style="clear:both; "></div>
			<div style="clear:both;"></div>
			<div id="related-posts" style="margin-top:28px;"> 
				
			</div>
			<div>
                <div style="margin-top:-12px";>
                    <h3>Comentarios</h3>
                </div>
                <div id="fb-root"></div>
              	<script src="http://connect.facebook.net/es_CO/all.js#xfbml=1"></script>
        			<fb:comments href="<?php the_permalink() ?>" width="645"></fb:comments >
            	</div>
			</div>
		</div>
        <?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
		<?php endif; ?>
        <?php get_sidebar(); ?>  
   </div>
</div>
<?php get_footer(); ?>