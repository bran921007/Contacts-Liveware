<?php get_header(); ?>
<div id="wrapper" class="hfeed">
	<div id="main">
		<div id="container">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        	<div id="content" role="main">
				<h1> <strong><?php the_title(); ?></strong></h1>
                <p><?php the_content('Continuar leyendo..'); ?></p>
			</div>
            <?php endwhile; ?>
            <?php endif; ?>
		</div>
        <?php get_sidebar(); ?> 
	</div>
</div>
<?php get_footer(); ?>