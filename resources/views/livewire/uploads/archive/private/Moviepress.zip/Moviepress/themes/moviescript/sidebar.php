<div id="primary" class="widget-area" role="complementary">
	<ul class="xoxo">
		<li id="text-2" class="widget-container widget_text">			
        	<div class="textwidget">
            	<div style="margin-top:10px; background:#f8f8f8; border: 1px solid #b20000;">
				<img src="<?php bloginfo( 'template_url' ); ?>/css/images/headerfiltro.png" width:300px;>
                <center><strong>Buscar película por Género / Año:</strong></center>
				<div style="margin-top:-10px";>
					<div style="margin-left:15px";>
                        <form action="<?php bloginfo('url'); ?>/" method="get"><br />
							<?php
                            $select = wp_dropdown_categories('show_option_none=Género&show_count=0&orderby=name&echo=0&selected=6');
                            $select = preg_replace("#<select([^>]*)>#", "<select$1 onchange='return this.form.submit()'>", $select);
                            echo $select;
                            ?>
                            <input type="submit" value="IR" />
						</form>
                	</div>
                    <div style="margin-right:13px";>
						<div align="right" style="margin-top:-43px";>
                        	<form action="<?php bloginfo('url'); ?>/" method="get"><br />
                            <select name='fecha-estreno' id='fecha-estreno' class='postform'  onchange='return this.form.submit()'>
                            <option value='-1'>Año</option>
                            <?php 		
							$args = array(
							  'taxonomy'     => 'fecha-estreno',
							  'orderby'      => 'name',
							  'show_count'   => 0,
							  'pad_counts'   => 0,
							  'hierarchical' => 1,
							  'title_li'     => false
							);
							$serie = get_categories($args);
							foreach ($serie as $s)
							{
							?>
                            <option value="<?=$s->name;?>"><?=$s->name;?></option>
							<?php
							}
							?>
							</select>
                            <input type="submit" value="IR" />
						</form>
                     	</div>
                   	</div>
				</div>
				<div style="margin-top:8px;"></div>
				</div>
                <!-- BOX 2 -->
                <div style="margin-top:10px; background:#f8f8f8; border: 1px solid #b20000;">
				<img src="<?php bloginfo( 'template_url' ); ?>/css/images/headeralfabetico.png" width:300px;>
				<div style="margin-top:5px";>
					<div style="margin-left:10px";>
                        <input type="button" value="A" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-A'" /> <input type="button" value="B" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-B'" /> <input type="button" value="C" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-C'" /> <input type="button" value="D" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-D'" /> <input type="button" value="E" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-E'" /> <input type="button" value="F" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-F'" /> <input type="button" value="G" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-G'" /> <input type="button" value="H" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-H'" /> <input type="button" value="I" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-I'" /> <input type="button" value="J" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-J'" /> <input type="button" value="K" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-K'" /> <input type="button" value="L" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-L'" /> <input type="button" value="M" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-M'" /> <input type="button" value="N" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-N'" /> <input type="button" value="O" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-O'" /> <input type="button" value="P" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-P'" /> <input type="button" value="Q" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-Q'" /> <input type="button" value="R" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-R'" /> <input type="button" value="S" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-S'" /> <input type="button" value="T" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-T'" /> <input type="button" value="U" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-U'" /> <input type="button" value="V" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-V'" /> <input type="button" value="W" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-W'" /> <input type="button" value="X" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-X'" /> <input type="button" value="Y" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-Y'" /> <input type="button" value="Z" class="button-letra" onmouseover="this.className='button-letra-hover'" onmouseout="this.className='button-letra'" onClick="location.href='<?php bloginfo('url'); ?>/?s=letra-Z'" /> 
                	</div>
				</div>
				<div style="margin-top:8px;"></div>
				</div>
            </div>	
		</li>
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?> <?php endif; ?>
	</ul>
</div>