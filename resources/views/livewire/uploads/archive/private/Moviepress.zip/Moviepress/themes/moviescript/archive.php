<?php get_header(); ?>
<div id="wrapper" class="hfeed">
	<div id="main">
		<div id="container">
        	<div id="content" role="main">
				<h1> <strong>Listado de Peliculas</strong><div align="right" style="margin-top:-25px;"><a href="<?php echo get_settings('home'); ?>/archivos/estrenos/"><img src="<?php bloginfo( 'template_url' ); ?>/css/images/estrenos.png" title="Ver Estrenos" /></a>&nbsp;</div></h1>
                <?php if (have_posts()) : ?>
            	<?php while (have_posts()) : the_post(); ?>
                <div class="poster post-<?php the_ID(); ?>">
                	<a class="aimg" href="<?php the_permalink() ?>" rel="tooltip" title='<h2><?php the_title(); ?></h2><p><?php wp_limit_post(170,'[...]',true); ?></p><h2></h2><p></p><p><strong>Reparto: </strong><?php echo get_the_term_list($post->ID, 'actor', '', ', ', ''); ?></p><p><strong>Género: </strong><?php the_category(', '); ?></p><p><strong>Duración: </strong><?php $values = get_post_custom_values("Runtime"); echo $values[0]; ?></p>'>
                    <?php the_post_thumbnail(array(128,171)); ?></a>
                    <div class="mdata">
                    	<a href="<?php the_permalink() ?>"><strong><?php the_title(); ?></strong></a><br />
              			<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
					</div>
				</div>
                <?php endwhile; ?>	
                				<hr width=100%>
				<?php wp_pagenavi(); ?>
                <?php else : ?>

                <h2>No se ha encontrado</h2>
                <p>Lo sentimos, pero que esta buscando algo que no esta aqui. </p>
        
                <?php endif; ?>
			</div>
		</div>
        <?php get_sidebar(); ?> 
	</div>
</div>
<?php get_footer(); ?>