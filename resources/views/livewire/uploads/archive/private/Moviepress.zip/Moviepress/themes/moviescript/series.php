<?php
/*
Template Name: Series
*/
?>
<?php get_header(); ?>
<!-- http://www.marcofbb.com.ar/ --><!-- Powered by MoviePress -->
<link rel='stylesheet' id='seriesnav-css'  href='<?php bloginfo( 'template_url' ); ?>/css/seriesnav.css?ver=3.3.1' type='text/css' media='all' />
<div id="wrapper" class="hfeed">
	<div id="main">
        <div style="margin-top:10px;">
            <h1><center></center></h1>
        </div>
		<div class="post">
			<div class="entrytext">
				<div id="seriesnav-desc"></div>
				<div id="seriesnav">
				    <div id="seriesnav-title">
						<div class="column1"><center>1. Elige una Serie</center></div>
						<div class="column"><center>2. Selecciona una Temporada</center></div>
						<div class="column"><center>3. Elige un Episodio</center></div>
						<div class="clear"></div>
					</div>
					<div id="serie-search">
					<input id="search-input" value="Buscar Serie..." onclick = "if(this.value=='Buscar Serie...') this.value=''" type="text"/>
       			</div>
				<div id="seriesnav-selector">
					<div id="series-list" class="column1">
						<?php 		
							$args = array(
							  'taxonomy'     => 'serie',
							  'orderby'      => 'name',
							  'show_count'   => 0,
							  'pad_counts'   => 0,
							  'hierarchical' => 1,
							  'title_li'     => false
							);
							?>							
							<ul>
                            <?php
							$serie = get_categories($args);
							foreach ($serie as $s)
							{
							?>
							<li><a href="<?=$s->cat_ID;?>"><?=$s->name;?></a></li>
							<?php
							}
							?>
							</ul>
					</div>
					<div id="season-list" class="column"></div>
					<div id="episode-list" class="column"></div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="loading-hide">
				<div id="loading-gif">
					<img src="<?php bloginfo('url'); ?>/wp-content/plugins/seriesnav/img/load.gif"/>
				</div>
			 </div>
			<script type='text/javascript'>
			  <!--
			  jQuery(document).ready(function () {

				/*var arraySearch=new Array();			
				jQuery.each(jQuery("#series-list li a"), function(i) {			
					  arraySearch[i] = jQuery(this).text();			
				});
				jQuery("#search-input").autocomplete({			
					source: arraySearch,			
					appendTo: "#series-list"			
				});*/
				jQuery('#search-input').quicksearch('#series-list li');
			
				function showLoading() {
				  loading = jQuery("#loading-hide").html();
				  jQuery("#seriesnav-desc").html(loading);
				}
				jQuery("#series-list li a").click(function (event) {
				  event.preventDefault();
				  showLoading();
				  jQuery("#season-list").empty();
				  jQuery("#episode-list").empty();
				  serieId = jQuery(this).attr("href");
				  console.log('serieName: ' + serieId);
				  jQuery.ajax({
					type: "POST",
					url: "<?php bloginfo( 'template_url' ); ?>/ajax/seriesajaxresp.php",
					data: {
					  serie: serieId,
					  status: 0
					},
					success: function (data) {
					  console.log('click req series ' + data);
					  jQuery("#seriesnav-desc").empty();
					  jQuery("#season-list").html(data);
					  jQuery("#seriesnav-desc").html(jQuery("#hidden-desc").html());
					}
				  });
				});
				jQuery("#season-list li").live("click", "a", function (event) {
				  event.preventDefault();
				  showLoading();
				  jQuery("#episode-list").empty();
				  serieId = jQuery(this).find("a").attr("href");
				  console.log('serieId: ' + serieId);
				  jQuery.ajax({
					type: "POST",
					url: "<?php bloginfo( 'template_url' ); ?>/ajax/seriesajaxresp.php",
					data: {
					  serie: serieId,
					  status: 1
					},
					success: function (data) {
					  console.log('click req episodes ' + data);
					  jQuery("#seriesnav-desc").empty();
					  jQuery("#episode-list").html(data);
					  jQuery("#seriesnav-desc").html(jQuery("#hidden-desc-season").html())
					}
				  });
				});
				jQuery("#episode-list li").live("click", "a", function (event) {
				  event.preventDefault();
				  showLoading();
				  serieName = jQuery(this).text();
				  postID = jQuery(this).find("a").attr("href");
				  console.log('serieName: ' + serieName + " id: " + postID);
				  jQuery.ajax({
					type: "POST",
					url: "<?php bloginfo( 'template_url' ); ?>/ajax/seriesajaxresp.php",
					data: {
					  //serie: serieName,
					  status: 2,
					  id: postID
					},
					success: function (data) {
					  //console.log('click req ep details ['+postID +'] '+data);
					  jQuery("#seriesnav-desc").empty();
					  jQuery("#seriesnav-desc").html(data);
					}
				  });
				});
			  });
			  (function ($, window, document, undefined) {
				$.fn.quicksearch = function (target, opt) {
				  var timeout, cache, rowcache, jq_results, val = '',
					e = this,
					options = $.extend({
					  delay: 100,
					  selector: null,
					  stripeRows: null,
					  loader: null,
					  noResults: '',
					  bind: 'keyup',
					  onBefore: function () {
						return;
					  },
					  onAfter: function () {
						return;
					  },
					  show: function () {
						this.style.display = "";
					  },
					  hide: function () {
						this.style.display = "none";
					  },
					  prepareQuery: function (val) {
						return val.toLowerCase().split(' ');
					  },
					  testQuery: function (query, txt, _row) {
						for(var i = 0; i < query.length; i += 1) {
						  if(txt.indexOf(query[i]) === -1) {
							return false;
						  }
						}
						return true;
					  }
					}, opt);
				  this.go = function () {
					var i = 0,
					  noresults = true,
					  query = options.prepareQuery(val),
					  val_empty = (val.replace(' ', '').length === 0);
					for(var i = 0, len = rowcache.length; i < len; i++) {
					  if(val_empty || options.testQuery(query, cache[i], rowcache[i])) {
						options.show.apply(rowcache[i]);
						noresults = false;
					  }
					  else {
						options.hide.apply(rowcache[i]);
					  }
					}
					if(noresults) {
					  this.results(false);
					}
					else {
					  this.results(true);
					  this.stripe();
					}
					this.loader(false);
					options.onAfter();
					return this;
				  };
				  this.stripe = function () {
					if(typeof options.stripeRows === "object" && options.stripeRows !== null) {
					  var joined = options.stripeRows.join(' ');
					  var stripeRows_length = options.stripeRows.length;
					  jq_results.not(':hidden').each(function (i) {
						$(this).removeClass(joined).addClass(options.stripeRows[i % stripeRows_length]);
					  });
					}
					return this;
					  };
				  this.strip_html = function (input) {
					var output = input.replace(new RegExp('<[^<]+\>', 'g'), "");
					output = $.trim(output.toLowerCase());
					return output;
				  };
				  this.results = function (bool) {
					if(typeof options.noResults === "string" && options.noResults !== "") {
					  if(bool) {
						$(options.noResults).hide();
					  }
					  else {
						$(options.noResults).show();
					  }
					}
					return this;
				  };
				  this.loader = function (bool) {
					if(typeof options.loader === "string" && options.loader !== "") {
					  (bool) ? $(options.loader).show() : $(options.loader).hide();
					}
					return this;
				  };
				  this.cache = function () {
					jq_results = $(target);
					if(typeof options.noResults === "string" && options.noResults !== "") {
					  jq_results = jq_results.not(options.noResults);
					}
					var t = (typeof options.selector === "string") ? jq_results.find(options.selector) : $(target).not(options.noResults);						cache = t.map(function () {
					  return e.strip_html(this.innerHTML);
					});
					rowcache = jq_results.map(function () {
					  return this;
					});
					return this.go();
				  };
				  this.trigger = function () {
					this.loader(true);
					options.onBefore();
					window.clearTimeout(timeout);
					timeout = window.setTimeout(function () {
					  e.go();
					}, options.delay);
					return this;
				  };
				  this.cache();
				  this.results(true);
				  this.stripe();
				  this.loader(false);
				  return this.each(function () {
					$(this).bind(options.bind, function () {
					  val = $(this).val();
					  e.trigger();
					});
				  });
				};
			  }(jQuery, this, document));
			  // -->
            </script>
		</div>
	</div>
	<div style="margin-top:-25px;">
		<center><strong>Si no te aparece nada en la lista, por favor espera unos segundos a veces puede tardar.</strong></center>
	</div>
	<h1></h1>
</div>
</div>
</div>
<div id="footer">
	<div class="container1">
		<div id="copyleft">
	           Es de vital importancia recordar que el diseño y esquema de MovieScript han sido BASADOS en la popular página Tekilaz! cuyos créditos y derechos de autor no pretenden ser adueñados, dichos diseños y esquemas han sido adoptados a MovieScript con fines meramente EDUCATIVOS y no se pretende LUCRAR con los mismos.
                <?php wp_footer(); ?>		
		</div>
	</div>
</div>
</body>
</html>
<!-- http://www.marcofbb.com.ar/ --><!-- Powered by MoviePress -->