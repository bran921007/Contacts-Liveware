<?php 
/* Short and sweet */
define('WP_USE_THEMES', false);
require('../../../../wp-blog-header.php');
status_header(200);
nocache_headers();
?>
<?php
$status = (int) $_POST['status'];
$serieId = htmlentities($_POST['serie']);
global $wpdb;
if($status == 0){
	$sql = "SELECT * FROM $wpdb->term_taxonomy WHERE term_id = '{$serieId}' and taxonomy = 'serie'";
	$res = $wpdb->get_results($sql);
	$query = $res[0]->term_taxonomy_id;
	$sql = "SELECT * FROM  $wpdb->term_relationships WHERE term_taxonomy_id = '{$query}'";
	$res = $wpdb->get_results($sql);
	$i = 0;
	$query = "";
	foreach($res as $key){
		if($i > 0){ $query.= " or object_id = '{$key->object_id}'"; } else { $query = "object_id = '{$key->object_id}'"; }
		$i++;
	}
	$sql = "SELECT * FROM  $wpdb->term_relationships WHERE {$query} ";
	$res = $wpdb->get_results($sql);
	$i = 0;
	$query = "";
	foreach($res as $key){
		$sql = "SELECT * FROM  $wpdb->term_taxonomy WHERE term_taxonomy_id = '{$key->term_taxonomy_id}'";
		$res2 = $wpdb->get_results($sql);
		foreach($res2 as $key2){
			if($key2->taxonomy == 'temporada'){
				if($key2->count > '0'){
					if($i > 0){ $query.= " or term_id = '{$key2->term_id}'"; } 
					else { $query = "term_id = '{$key2->term_id}'"; }
					$i++;
				}
			}
		}
	}
	$sql = "SELECT * FROM $wpdb->terms WHERE {$query} ORDER BY name ASC";
	$res = $wpdb->get_results($sql);
}elseif($status == 1){
	$data = explode("-",$serieId);
	$serieId = $data[0];
	$temporada = $data[1];
	//
	$sql = "SELECT * FROM $wpdb->terms WHERE term_id = '{$serieId}'";
	$res = $wpdb->get_results($sql);
	$serieName = $res[0]->slug;
	//
	$res = query_posts("temporada={$temporada}&serie={$serieName}&posts_per_page=500");
	//
	foreach($res as $key){
		$terms = get_the_terms( $key->ID, 'capitulo' ); 
		foreach ( $terms as $term ) { 
			$postData[$term->name]["ID"] = $key->ID;
			$postData[$term->name]["post_title"] = $key->post_title;
			$postData[$term->name]["capitulo"] = $term->name; 
			$i++;
		} 
	}
	ksort($postData);
}elseif($status == 2){
	$postId = (int) $_POST['id'];
	$res = query_posts("p={$postId}&posts_per_page=1");
} else {
	exit("-1");	
}
?>
<?php if($status == 0){ ?>
<ul><?php foreach($res as $key){ ?><li><a href="<?php echo $serieId; ?>-<?php echo $key->name; ?>">Temporada <?php echo $key->name; ?></a></li><?php } ?></ul>
<?php } elseif($status == 1){ ?>
<ul><?php foreach($postData as $key){ ?><li><a href="<?php echo $key["ID"]; ?>"><?php echo $key["capitulo"]; ?>: <?php echo $key["post_title"]; ?></a></li><?php } ?></ul>
<?php } elseif($status == 2){ 
foreach($res as $key){
?>
<div style='float:left; margin-right:10px; margin-bottom:10px;'><?php echo get_the_post_thumbnail( $key->ID, array(128,171) ); ?></div><p><div><strong><u><?php echo $key->post_title; ?></u></strong></div></p><div><strong>Sinopsis:</strong> <?php echo $key->post_content; ?><p><div><a href='<?php echo get_permalink( $key->ID ); ?>'><img src='<?php bloginfo( 'template_url' ); ?>/css/images/ver-capitulo.png'/></a></div></p></div><div style='clear:both;'></div>
<?php }} ?>