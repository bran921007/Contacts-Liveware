<div id="footer">
	<div class="container1">
		<div id="copyleft">
	           Es de vital importancia recordar que el diseño y esquema de MovieScript han sido BASADOS en la popular página Tekilaz! cuyos créditos y derechos de autor no pretenden ser adueñados, dichos diseños y esquemas han sido adoptados a MovieScript con fines meramente EDUCATIVOS y no se pretende LUCRAR con los mismos.
                <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
                <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/jquery.jscrollpane.lozenge.css" />
				<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/jquery.jscrollpane.css" />
				<script type='text/javascript' src="<?php bloginfo( 'template_url' ); ?>/js/jquery.jscrollpane.min.js"></script>

                <?php wp_footer(); ?>		
		</div>
	</div>
</div>
</body>
</html>
<!-- http://www.marcofbb.com.ar/ --><!-- Powered by MoviePress Script for Wordpress -->